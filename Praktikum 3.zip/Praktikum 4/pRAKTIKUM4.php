<?php
class NilaiMahasiswa {
    var $nim;
    var $mata_kuliah;
    var $nilai;
    var $grade;

    function ___construct($nim, $mata_kuliah, $nilai, $grade) {
        $this->nim = $nim;
        $this ->nama = $mata_kuliah;
        $this->nilai = $nilai;
        $this->grade = $grade;
    }
   //method grade 
function grade_nilai($grade){ 
    if($grade> 100){
         return "A"; 
        } else if ($grade > 70){ 
            return "B"; 
        } else if ($grade> 56){
            return "C"; 
        }else if ($grade > 36){ 
            return "D"; 
        } else if( $grade> 0){
             return "E"; 
        }else { 
            return "I"; 
        }
}
}
?>