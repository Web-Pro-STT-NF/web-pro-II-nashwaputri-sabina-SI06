<?php
class NilaiMahasiswa {
    var $nim;
    var $mata_kuliah;
    var $nilai;

    function ___construct($nim, $mata_kuliah, $nilai, $grade) {
        $this->nim = $nim;
        $this ->nama = $mata_kuliah;
        $this->nilai = $nilai;
        $this->grade = $grade;
    }
   //method grade 
function grade_nilai($IPK){ 
    if($IPK > 100){
         return "A"; 
        } else if ($IPK > 70){ 
            return "B"; 
        } else if ($IPK > 56){
            return "C"; 
        }else if ($IPK > 36){ 
            return "D"; 
        } else if($IPK > 0){
             return "E"; 
        }else { 
            return "I"; 
        }
}
}
?>