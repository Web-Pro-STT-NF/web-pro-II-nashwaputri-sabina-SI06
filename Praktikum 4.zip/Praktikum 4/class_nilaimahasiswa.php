<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>fORM NILAI UJIAN</title>
    <title>fORM NILAI UJIAN</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"> 
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
<form class="form-horizontal">
  <div class="form-group">
    <label for="NIM" class="control-label col-xs-4">NIM</label> 
    <div class="col-xs-5">
      <input id="nim" name="nim" type="text" class="form-control">
    </div>
  </div>
  <div class="form-group">
    <label for="Pilih mata kuliah" class="control-label col-xs-4">Mata kuliah</label> 
    <div class="col-xs-5">
      <select id="mata_kuliah" name="mata_kuliah" class="select form-control">
        <option value="Data Web">Data Web</option>
        <option value="Basis Data">Basis Data</option>
        <option value="Dasar Program">Dasar Program</option>
        <option value="Matematika Komputer">Matematika Komputer</option>
      </select>
    </div>
  </div>
  <div class="form-group">
    <label for="nilai" class="control-label col-xs-4">Nilai</label> 
    <div class="col-xs-5">
      <input id="nilai" name="nilai" type="text" class="form-control">
    </div>
  </div> 
  <div class="form-group row">
    <div class="col-xs-offset-4 col-xs-8">
      <button name="Simpan" type="Simpan" class="btn btn-primary">Simpan</button>
    </div>
  </div>
</form>

<?php
                include_once 'pRAKTIKUM4.php';
                $proses =isset($_GET['proses']) ? $_GET['proses'] : '';
                $nim=isset($_GET['nim']) ? $_GET['nim'] : '';
                $nilai = isset($_GET['nilai']) ? $_GET['nilai'] : '';
                $mata_kuliah = isset($_GET['mata_kuliah']) ? $_GET['mata_kuliah'] : '';
                $grade = isset($_GET['grade']) ? $_GET['grade'] : '';
                
                echo '</br>Proses : ' .$proses;
                echo '</br>Nim : ' .$nim;
                echo '</br>Mata Kuliah : ' .$mata_kuliah;
                echo '</br>Nilai : ' .$nilai;

                echo '</br>grade : ' .$grade;
                ?>
            </div>
        </div>
        <div class="row">
            <div class="col-12 bg-light pt-3"></div>
            <p>Develop by Mahasiswa</p>
        </div>
    </div>
</body>
</html>
