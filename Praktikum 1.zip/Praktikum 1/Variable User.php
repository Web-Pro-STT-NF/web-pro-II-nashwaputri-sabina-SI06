<?php
// definisikan variables
$nama = 'Nashwa Putri sabina';
$umur = 19;
$berat = 60;

echo 'Nama : ' . $nama;
echo '<br/>Umur : ' . $umur.' Tahun';
echo '<br/>Berat : '.$berat.' Kg';

echo "<br/>Hello $nama Apakabar";

?>
