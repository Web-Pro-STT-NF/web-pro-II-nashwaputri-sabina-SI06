<?php
include_once 'Header.php';
include_once 'Sidebar.php';
?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Data Dosen</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item"><a href="#">Layout</a></li>
              <li class="breadcrumb-item active">Data Dosen</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">

      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <!-- Default box -->
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Nama Dosen</h3>

                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                    <i class="fas fa-minus"></i>
                  </button>
                  <button type="button" class="btn btn-tool" data-card-widget="remove" title="Remove">
                    <i class="fas fa-times"></i>
                  </button>
                </div>
              </div>
              <div class="card-body">
              <div class="container-fluid">
	<div class="row">
		<div class="col-md-12">
        <div class="container-fluid">
	<div class="row">
		<div class="col-md-12">
        <div class="container-fluid">
	<div class="row">
		<div class="col-md-12">
			<div class="card">
            <div class="container-fluid">
	<div class="row">
		<div class="col-md-12">
			<table class="table">
				<thead>
					<tr>
						<th>
							Kode
						</th>
						<th>
							Nama Dosen
						</th>
						<th>
							Program studi
						</th>
						<th>
							NIDN
						</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td>
							007
						</td>
						<td>
							Karina Azkia S.Kom S.Pd
						</td>
						<td>
							Pemorgraman Web
						</td>
						<td>
							01123457
						</td>
					</tr>
					<tr class="table-active">
						<td>
							032
						</td>
						<td>
							Anton Wijaya M.M 
						</td>
						<td>
							Basis Data
						</td>
						<td>
							01132567
						</td>
					</tr>
					<tr class="table-success">
						<td>
							206
						</td>
						<td>
							Fani Rosmianti S.Si
						</td>
						<td>
							Jaringan Komputer
						</td>
						<td>
							01176549
						</td>
					</tr>
					<tr class="table-warning">
						<td>
							097
						</td>
						<td>
							Sania Buana S.T S.pd
						</td>
						<td>
							Administrasi Jaringan
						</td>
						<td>
							01156748
						</td>
					</tr>
					<tr class="table-danger">
						<td>
							006
						</td>
						<td>
							Jaya Gitabuana M.kom
						</td>
						<td>
							Bisnis Digital
						</td>
						<td>
							011134267
						</td>
					</tr>
                    <tr>
						<td>
							007
						</td>
						<td>
							Rania S.Kom S.Pd
						</td>
						<td>
							PKN
						</td>
						<td>
							01123457
						</td>
					</tr>
					<tr class="table-active">
						<td>
							032
						</td>
						<td>
							Hamzah Fahwan S.T
						</td>
						<td>
							Design Grafis
						</td>
						<td>
							01132567
						</td>
					</tr>
					<tr class="table-success">
						<td>
							002
						</td>
						<td>
							Ahmah Alif M.kom
						</td>
						<td>
							Web Development
						</td>
						<td>
							01176549
						</td>
					</tr>
					<tr class="table-warning">
						<td>
							093
						</td>
						<td>
							Dini Gitabuana M.kom
						</td>
						<td>
							Teknologi Virtualisasi
						</td>
						<td>
							01156748
						</td>
					</tr>
				</tbody>
			</table>
		</div>
	</div>
</div>
<?php
include_once 'Footer.php';
?>