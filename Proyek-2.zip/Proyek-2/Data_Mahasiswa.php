<?php
include_once 'Header.php';
include_once 'Sidebar.php';
?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Data Mahasiswa</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item"><a href="#">Layout</a></li>
              <li class="breadcrumb-item active">Data Mahasiswa</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">

      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <!-- Default box -->
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Isi Data Mahasiswa</h3>

                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                    <i class="fas fa-minus"></i>
                  </button>
                  <button type="button" class="btn btn-tool" data-card-widget="remove" title="Remove">
                    <i class="fas fa-times"></i>
                  </button>
                </div>
              </div>
              <div class="card-body">
              <div class="container-fluid">
	<div class="row">
		<div class="col-md-12">
        <div class="container-fluid">
	<div class="row">
		<div class="col-md-12">
			<table class="table table-bordered table-hover">
				<thead>
					<tr>
						<th>
							NO
						</th>
						<th>
							Nama Mahasiswa
						</th>
						<th>
							Program Studi
						</th>
						<th>
							NIM
						</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td>
							1
						</td>
						<td>
							Gani kusuma
						</td>
						<td>
							Sistem Informasi
						</td>
						<td>
							0113976
						</td>
					</tr>
					<tr class="table-active">
						<td>
							2
						</td>
						<td>
							Anita Raharjo
						</td>
						<td>
							Teknik Informatika
						</td>
						<td>
							0113979
						</td>
					</tr>
					<tr class="table-success">
						<td>
							3
						</td>
						<td>
							Jennie Rahayu
						</td>
						<td>
							Sistem Informasi
						</td>
						<td>
							<span>0113976</span>
						</td>
					</tr>
					<tr class="table-warning">
						<td>
							4
						</td>
						<td>
							Irfan Kalla
						</td>
						<td>
							Teknik Informatika
						</td>
						<td>
							<span>0113976</span>
						</td>
					</tr>
					<tr class="table-danger">
						<td>
							5
						</td>
						<td>
							Lidoo Muhammad
						</td>
						<td>
							Sistem Informasi
						</td>
						<td>
							<span>0113976</span>
						</td>
					</tr>
                    <tr>
						<td>
							6
						</td>
						<td>
							Sukma Tiyasa
						</td>
						<td>
							Sistem Informasi
						</td>
						<td>
							0112645
						</td>
					</tr>
                    <tr class="table-warning">
						<td>
							7
						</td>
						<td>
							Ajeng Hanira
						</td>
						<td>
							Teknik Informatika
						</td>
						<td>
							<span>0117656</span>
						</td>
					</tr>
					<tr class="table-danger">
						<td>
							8
						</td>
						<td>
							Siska Hidayat
						</td>
						<td>
							Sistem Informasi
						</td>
						<td>
							<span>0121576</span>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
	</div>
</div>
               
<?php
include_once 'Footer.php';
?>