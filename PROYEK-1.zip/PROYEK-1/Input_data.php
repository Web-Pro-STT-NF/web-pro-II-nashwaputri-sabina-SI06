<?php
include_once "Data_pasien.php";
include_once "class_bmipasien.php";
include_once "class_BMI.php";
?>